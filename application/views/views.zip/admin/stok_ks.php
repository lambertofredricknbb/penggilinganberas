<?php 
date_default_timezone_set("Asia/Jakarta");
  function tgl_indo($tanggal){
      $bulan = array (
          1 =>   'Januari',
          'Februari',
          'Maret',
          'April',
          'Mei',
          'Juni',
          'Juli',
          'Agustus',
          'September',
          'Oktober',
          'November',
          'Desember'
      );
      $pecahkan = explode('-', $tanggal);
      
      // variabel pecahkan 0 = tanggal
      // variabel pecahkan 1 = bulan
      // variabel pecahkan 2 = tahun
   
      return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
  }
   ?>
<div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Stock Kering Sawah</li>
                </ol>
              </nav>
            </div>
          </div>
          <!-- Card stats -->
          <div class="row justify-content-center">
            
            <div class="col-md-12">
              
            </div>

          </div>
        </div>
      </div>
    </div>

    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
                <div class="card-header border-0">
                  <div class="row align-items-center">
                    <div class="col">
                      <h3 class="mb-0">Stock Kering Sawah</h3>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                    <div class="row">
                      <div class="col-md-12">

                        <div class="table-responsive">
                          <!-- Projects table -->
                          <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                              <tr class="text-center">
                                <th><b style="font-weight: 900;">Grade</b></th>
                                <?php foreach ($jenis as $j): ?>
                                <th><b><?= $j['nama_jenis'] ?></b></th>
                                <?php endforeach ?>
                              </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($grade as $g): ?>
                                    <tr class="text-center">
                                        <td><b><?= $g['nama_grade'] ?></b></td>
                                        <?php foreach ($jenis as $j): ?>
                                        <?php
                                          $this->db->select('SUM(tonase) as total_tonase');
                                          $this->db->from('tb_pengeringan');
                                          // $this->db->where('tb_pengeringan.musim', 'rojoan');
                                          $this->db->where('tb_pengeringan.jenis_gabah', $j['id_jenis']);
                                          $this->db->where('tb_pengeringan.grade', $g['id_grade']);
                                          $tona = $this->db->get()->row()->total_tonase;
                                        ?>

                                        <?php if ($tona != 0): ?>
                                            <td><?= $tona ?> Kg</td>
                                        <?php endif ?>
                                        <?php if ($tona == 0): ?>
                                            <td>-</td>
                                        <?php endif ?>
                                        <?php endforeach ?>
                                    </tr>                                 
                                <?php endforeach ?>                             
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    
                </div>
                
              </div>
        </div>
      </div>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
    // kode pembelian
    $(document).ready(function() {
        $.ajax({
            type: 'GET',
            url: '<?php echo base_url(); ?>admin/getNotaJual',
            beforeSend: function() {
                $('.loading').show();
            },
            success: function(data) {

                var html = JSON.parse(data);
                var kode = 'JKG_' + html;
                var nodaf = kode;
                $('#nota_penjualan').val(nodaf);
            }
        });
    });
    $(document).ready(function() {
        $.ajax({
            type: 'GET',
            url: '<?php echo base_url(); ?>admin/getNotaBeli',
            beforeSend: function() {
                $('.loading').show();
            },
            success: function(data) {

                var html = JSON.parse(data);
                var kode = 'BKG_' + html;
                var nodaf = kode;
                $('#kode_pembelian').val(nodaf);
            }
        });
    });
    $('#tonase').keyup(function(){
        var tonase = $('#tonase').val();
        var harga_kg = $('#harga_kg').val();
        var total = Number(tonase) * Number(harga_kg)
        $('#total').val(total);
    });
    $('#harga_kg').keyup(function(){
        var tonase = $('#tonase').val();
        var harga_kg = $('#harga_kg').val();
        var total = Number(tonase) * Number(harga_kg)
        $('#total').val(total);
    });
    // 
    $('.tonase').keyup(function(){
        var tonase = $('.tonase').val();
        // var items = new Array();
        // var total = 0;
        var result = 0
        // var id= "";
        // var kosong = "";

        for (var i = 0; i < 3 ; i++) {
            result += parseFloat(tonase[i]);
        }
        $('#total_kg').val(result);
    });

</script>