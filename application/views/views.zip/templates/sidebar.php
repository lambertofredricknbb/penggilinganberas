
<body>
  <!-- Sidenav -->
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="javascript:void(0)">
          <img src="<?= base_url('vendor/argon/') ?>assets/img/brand/blue.png" class="navbar-brand-img" alt="...">
        </a>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" href="<?= base_url('admin/index') ?>">
                <i class="ni ni-tv-2 text-primary"></i>
                <span class="nav-link-text">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/pembelian') ?>">
                <i class="ni ni-app text-primary"></i>
                <span class="nav-link-text">Pembelian Gabah KS</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/stok_ks') ?>">
                <i class="ni ni-app text-primary"></i>
                <span class="nav-link-text">Stok Gabah KS</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/proses_pengeringan') ?>">
                <i class="ni ni-map-big text-primary"></i>
                <span class="nav-link-text">Proses Pengeringan</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/stock_siap_giling') ?>">
                <i class="ni ni-bag-17 text-primary"></i>
                <span class="nav-link-text">Stock Kering Giling</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/proses_giling') ?>">
                <i class="ni ni-vector text-primary"></i>
                <span class="nav-link-text">Proses Giling</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/stok_beras_giling') ?>">
                <i class="ni ni-archive-2 text-primary"></i>
                <span class="nav-link-text">Stok Beras Giling</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/proses_kebi') ?>">
                <i class="ni ni-box-2 text-primary"></i>
                <span class="nav-link-text">Proses KEBI</span>
              </a>
            </li>
          </ul>
          <hr class="my-2">
          <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">Data Penggilingan</span>
          </h6>
          <ul class="navbar-nav mb-md-3">
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/jenis_beras') ?>">
                <i class="ni ni-tag"></i>
                <span class="nav-link-text">Data Jenis</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/merk_beras') ?>">
                <i class="ni ni-tie-bow"></i>
                <span class="nav-link-text">Data Merk</span>
              </a>
            </li>
          </ul>
          <!-- Divider -->
          <hr class="my-1">
          <!-- Heading -->
          <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">Akun</span>
          </h6>
          <!-- Navigation -->
          <ul class="navbar-nav mb-md-3">
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/data_user') ?>">
                <i class="ni ni-circle-08"></i>
                <span class="nav-link-text">Data User</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('auth/logout') ?>">
                <i class="ni ni-button-power"></i>
                <span class="nav-link-text">Log Out</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>