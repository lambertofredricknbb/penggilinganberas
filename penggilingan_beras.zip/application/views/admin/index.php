    
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="pe-7s-car icon-gradient bg-mean-fruit">
                                        </i>
                                    </div>
                                    <div>Analytics Dashboard
                                        <div class="page-title-subheading">Selamat Datang di Aplikasi Penggilingan Beras Balung.
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>            
                        <div class="row justify-content-center">

                            <div class="col-md-4">
                                <a style="text-decoration: none;" href="<?= base_url('admin/pembelian') ?>">
                                <div class="card mb-3 widget-content bg-arielle-smile">
                                    <!-- <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Clients</div>
                                            <div class="widget-subheading">Total Clients Profit</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span>$ 568</span></div>
                                        </div>
                                    </div> -->
                                    <div class="widget-content-center" style="margin-left: auto; margin-right: auto;">
                                            <div class="widget-numbers text-white text-center">
                                                <span style="text-align: center;">Pembelian</span>
                                            </div>
                                        </div>
                                </div>
                            </a>
                            </div>
                            <div class="col-md-4">
                                <a href="<?= base_url('admin/stock_siap_giling') ?>" style="text-decoration: none;">
                                <div class="card mb-3 widget-content bg-grow-early">
                                    <!-- <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Followers</div>
                                            <div class="widget-subheading">People Interested</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span>46%</span></div>
                                        </div>
                                    </div> -->
                                    <div class="widget-content-center" style="margin-left: auto; margin-right: auto;">
                                            <div class="widget-numbers text-white text-center">
                                                <span style="text-align: center;">Stock Siap Giling</span>
                                            </div>
                                        </div>
                                </div>
                            </a>
                            </div>
                            <div class="col-md-4">
                                <a href="<?= base_url('admin/giling') ?>" style="text-decoration: none;">
                                    <div class="card mb-3 widget-content bg-warning">
                                    <!-- <div class="widget-content-wrapper text-white">
                                        <div class="widget-content-left">
                                            <div class="widget-heading">Followers</div>
                                            <div class="widget-subheading">People Interested</div>
                                        </div>
                                        <div class="widget-content-right">
                                            <div class="widget-numbers text-white"><span>46%</span></div>
                                        </div>
                                    </div> -->
                                    <div class="widget-content-center" style="margin-left: auto; margin-right: auto;">
                                            <div class="widget-numbers text-white text-center">
                                                <span style="text-align: center;">Penggilingan</span>
                                            </div>
                                        </div>
                                </div>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="<?= base_url('admin/proses_ebi') ?>" style="text-decoration: none;">
                                <div class="card widget-content bg-midnight-bloom">
                                    <div class="widget-content-wrapper text-white text-center">
                                        <!-- <div class="widget-content-left">
                                            <div class="widget-heading">Penggilingan</div>
                                            <div class="widget-subheading">Last year expenses</div>
                                        </div> -->
                                        <div class="widget-content-center" style="margin-left: auto; margin-right: auto;">
                                            <div class="widget-numbers text-white text-center">
                                                <span style="text-align: center;">Proses Ebi</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                            <div class="col-md-4">
                                <a href="<?= base_url('admin/stock_beras') ?>" style="text-decoration: none;">
                                <div class="card widget-content bg-premium-dark">
                                    <div class="widget-content-wrapper text-white text-center">
                                        <!-- <div class="widget-content-left">
                                            <div class="widget-heading">Penggilingan</div>
                                            <div class="widget-subheading">Last year expenses</div>
                                        </div> -->
                                        <div class="widget-content-center" style="margin-left: auto; margin-right: auto;">
                                            <div class="widget-numbers text-white text-center">
                                                <span style="text-align: center;">Stock Beras</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            </div>
                        </div>
                    </div>
                    