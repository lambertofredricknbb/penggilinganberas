 <?php 
    function tgl_indo($tanggal){
    $bulan = array (
    1 =>   'Januari',
    'Februari',
    'Maret',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Agustus',
    'September',
    'Oktober',
    'November',
    'Desember'
    );
    $pecahkan = explode('-', $tanggal);

    // variabel pecahkan 0 = tanggal
    // variabel pecahkan 1 = bulan
    // variabel pecahkan 2 = tahun

    return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
    }
?>   
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="pe-7s-car icon-gradient bg-mean-fruit">
                                        </i>
                                    </div>
                                    <div>Stok Siap Giling
                                        <div class="page-title-subheading">Data Stock Gabah Siap Giling
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>            
                        <div class="row justify-content-center">
                            <div class="col-md-12">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h5 class="card-title">Tabel Pembelian</h5>
                                            </div>
                                            <div class="col-md-6" align="right">
                                                <a href="<?= base_url('admin/tambah_stock') ?>" class="btn btn-success"><i class="fas fa fa-plus"></i> Tambah Stock</a>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <table class="mb-0 table my-3 table-striped table-hovered">
                                                    <thead>
                                                        <tr class="text-center">
                                                            <th>Kode Nota</th>
                                                            <th>Supplier</th>
                                                            <th>Penyusutan</th>
                                                            <th>Tonase</th>
                                                            <th>Jenis Kering</th>
                                                            <th>Tanggal</th>
                                                            <th>Aksi</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($stock as $s) {?>
                                                        <tr class="text-center">
                                                            <th><?= $s['kode_pembelian']?></th>
                                                            <td><?= $s['nama_supplier']?></td>
                                                            <td><?= $s['penyusutan'] ?>%</td>
                                                            <td><?= $s['tonase_akhir']?> Kg</td>
                                                            <td><?= $s['jenis_kering']?></td>
                                                            <td><?= tgl_indo(date('Y-m-d', strtotime($s['tanggal']))) ?></td>
                                                            <td>
                                                                <a href="<?= base_url('admin/detail_stock_gabah/').$s['id_stok'] ?>" class="btn btn-success"><i class="fas fa fa-search-plus"></i></a>
                                                                <a href="<?= base_url('admin/hapus_stock_gabah/').$s['id_stok'] ?>" class="btn btn-danger"><i class="fas fa-trash"></i></a>
                                                            </td>
                                                        </tr>
                                                    <?php } ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    