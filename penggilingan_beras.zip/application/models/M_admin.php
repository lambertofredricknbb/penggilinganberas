<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * 
 */
class M_admin extends CI_Model
{

	public function pembelian()
	{
		$this->db->select('*');
		$this->db->from('tb_pembelian');
		$this->db->join('jenis_beras', 'tb_pembelian.jenis_gabah = jenis_beras.id_jenis');
		$this->db->join('grade', 'tb_pembelian.grade = grade.id_grade');
		$this->db->join('tb_user', 'tb_pembelian.id_user = tb_user.id_user');
		$this->db->group_by('tb_pembelian.kode_pembelian');
		$result = $this->db->get();
		return $result->result_array();
	}

	public function detail_pembelian($kode)
	{
		$this->db->select('*');
		$this->db->from('tb_pembelian');
		$this->db->join('jenis_beras', 'tb_pembelian.jenis_gabah = jenis_beras.id_jenis');
		$this->db->join('grade', 'tb_pembelian.grade = grade.id_grade');
		$this->db->join('tb_user', 'tb_pembelian.id_user = tb_user.id_user');
		$this->db->group_by('tb_pembelian.kode_pembelian');
		$this->db->where('tb_pembelian.kode_pembelian', $kode);
		$result = $this->db->get();
		return $result->result_array();
	}
	public function delete_pembelian($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }
    public function stock()
	{
		$this->db->select('*');
		$this->db->from('tb_stok_kg');
		$this->db->join('tb_pembelian', 'tb_pembelian.kode_pembelian = tb_stok_kg.kode_pembelian');
		$this->db->join('tb_user', 'tb_pembelian.id_user = tb_stok_kg.id_user');
		$this->db->group_by('tb_pembelian.kode_pembelian');
		$result = $this->db->get();
		return $result->result_array();
	}

}