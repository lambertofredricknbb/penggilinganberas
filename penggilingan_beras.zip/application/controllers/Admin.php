<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('M_admin');
	}

	public function index()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('admin/index', $data);
		$this->load->view('template/footer', $data);
	}
	// pembelian
	public function pembelian()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['pembelian'] = $this->M_admin->pembelian();
		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('admin/pembelian', $data);
		$this->load->view('template/footer', $data);
	}
	public function getKode()
    {
        // $this->load->model('model_data');
        $hasil = $this->db->query("select kode_pembelian from tb_pembelian ORDER BY kode_pembelian DESC LIMIT 1");
        if ($hasil->num_rows() > 0) {
            $nmr = explode('_', $hasil->row()->kode_pembelian);
            $data = sprintf("%04d", $nmr[1] + 1);
        } else {
            $data = '0001';
        }
        echo json_encode($data);
    }
    public function tambah_pembelian()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['jenis'] = $this->db->get('jenis_beras')->result_array();
		$data['grade'] = $this->db->get('grade')->result_array();
		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('admin/tambah_pembelian', $data);
		$this->load->view('template/footer');
	}
	public function proses_add_pembelian()
	{
		$this->form_validation->set_rules('id_user', 'User', 'trim|required');
		$this->form_validation->set_rules('kode_pembelian', 'Kode', 'trim|required');
		$this->form_validation->set_rules('nama_supplier', 'Suplier', 'trim|required');
		$this->form_validation->set_rules('nama_supir', 'Supir', 'trim|required');
		$this->form_validation->set_rules('plat', 'Plat', 'trim|required');
		if ($this->form_validation->run() == false) {
			$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
			$this->load->view('template/header', $data);
			$this->load->view('template/topbar', $data);
			$this->load->view('template/sidebar', $data);
			$this->load->view('admin/tambah_pembelian', $data);
			$this->load->view('template/footer', $data);
		}else{
			$id_user = $this->input->post('id_user');
            $kode_pembelian = $this->input->post('kode_pembelian');
            $nama_supplier = $this->input->post('nama_supplier');
            $nama_supir = $this->input->post('nama_supir');
            $plat = $this->input->post('plat');

            $jenis_gabah = $this->input->post('jenis_gabah[]');
            $grade = $this->input->post('grade[]');
            $tonase = $this->input->post('tonase[]');
            $harga_kg = $this->input->post('harga_kg[]');
            $total = $this->input->post('total[]');

            $no_penjemuran = $this->input->post('no_penjemuran');
            $keterangan = $this->input->post('keterangan');
            $tanggal = $this->input->post('tanggal');

            // 
            $result = [];
            $no = 0;
            $jenis_gabah = $this->input->post('jenis_gabah[]');
            foreach ($jenis_gabah as $key => $value) {
                $result[$no] = [
                	'id_user' => $id_user,
                    'kode_pembelian' => $kode_pembelian,
                    'nama_supplier' => $nama_supplier,
                    'nama_supir' => $nama_supir,
                    'plat' => $plat,
                    'jenis_gabah' => $_POST['jenis_gabah'][$no],
                    'grade' => $_POST['grade'][$no],
                    'tonase' => $_POST['tonase'][$no],
                    'harga_kg' => $_POST['harga_kg'][$no],
                    'total' => $_POST['total'][$no],
                    'jenis_kering' => $this->input->post('jenis_kering'),
                    'no_penjemuran' => $no_penjemuran,
                    'keterangan' => $keterangan,
                    'tanggal' => $tanggal
                ];
                $no++;
            }
            // 
            $this->db->insert_batch('tb_pembelian', $result);
            redirect('admin/pembelian');

		}

	}
	public function detail_pembelian()
	{
		$kode = $this->uri->segment(3);
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['detail'] = $this->M_admin->detail_pembelian($kode);
		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('admin/detail_pembelian', $data);
		$this->load->view('template/footer', $data);
	}
	public function hapus_pembelian()
	{
		$kode = $this->uri->segment(3);
		$where = array(
            'kode_pembelian' => $kode,
        );

        $this->M_admin->delete_pembelian($where, 'tb_pembelian');
        redirect('admin/pembelian');
	}

    // stock siap giling
	public function stock_siap_giling()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['stock'] = $this->M_admin->stock();
		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('admin/stock_siap_giling', $data);
		$this->load->view('template/footer', $data);
	}
	public function tambah_stock()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$data['pembelian'] = $this->M_admin->pembelian();
		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('admin/tambah_stock', $data);
		$this->load->view('template/footer', $data);
	}
	public function proses_add_stock()
	{
		$this->form_validation->set_rules('id_user', 'User', 'trim|required');
		$this->form_validation->set_rules('kode_pembelian', 'Kode', 'trim|required');
		$this->form_validation->set_rules('penyusutan', 'Penyusutan', 'trim|required');
		$this->form_validation->set_rules('tonase_akhir', 'Tonase', 'trim|required');
		$this->form_validation->set_rules('jenis_kering', 'Kering', 'trim|required');
		$this->form_validation->set_rules('tanggal', 'Tanggal', 'trim|required');
		if ($this->form_validation->run() == false) {
			$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
			$data['pembelian'] = $this->M_admin->pembelian();
			$this->load->view('template/header', $data);
			$this->load->view('template/topbar', $data);
			$this->load->view('template/sidebar', $data);
			$this->load->view('admin/tambah_stock', $data);
			$this->load->view('template/footer', $data);
		}else{
			$id_user = $this->input->post('id_user');
			$data = [
				'kode_pembelian' => $this->input->post('kode_pembelian'),
				'penyusutan' => $this->input->post('penyusutan'),
				'tonase_akhir' => $this->input->post('tonase_akhir'),
				
				'id_user' => $this->input->post('id_user'),
				'tanggal' => $this->input->post('tanggal'),

			];
			$this->db->insert('tb_stok_kg', $data);
            redirect('admin/stock_siap_giling');
		}
	}

	// giling
	public function giling()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('admin/giling', $data);
		$this->load->view('template/footer', $data);
	}
	public function proses_ebi()
	{
		$data['user'] = $this->db->get_where('tb_user', ['username' => $this->session->userdata('username')])->row_array();
		$this->load->view('template/header', $data);
		$this->load->view('template/topbar', $data);
		$this->load->view('template/sidebar', $data);
		$this->load->view('admin/proses_ebi', $data);
		$this->load->view('template/footer', $data);
	}
}
